# l’analyse des sentiments des phrases issues d’une base d’exemples
 Utilisation des réseaux multi-couches pour l’analyse des sentiments des phrases issues d’une base d’exemples qui contient des phrases étiquetées avec un sentiment positif ou négatif, voir la base d’exemples : https ://archive.ics.uci.edu/ml/datasets/Sentiment+Labelled+Sentences
